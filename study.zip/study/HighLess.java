public class HighLess extends Thread
{
  public static void main(String args[])
  {
   HighLess hl1 = new HighLess();
   HighLess hl2 = new HighLess();     
                                                                     // setting priorities       
   hl1.setPriority(Thread.MAX_PRIORITY-1eae);                           // 9
   hl2.setPriority(Thread.MIN_PRIORITY+1);                           // 3
                                                                     // setting the names
   hl1.setName("High");                                              // for 8  thread 
   hl2.setName("Less");                                              // for 3 thread   
                                                                     // to retrieve the priorities
   System.out.println("High Priority is "  + hl1.getPriority());     // prints 9
   System.out.println("Less Priority is " +  hl2.getPriority());     // prints 3
 
   hl2.start();                                                      // wantedly hl2 is started first
   hl1.start();    
  }
  public void run()
  {
    for(int i=0; i<10; i++)
    {
      System.out.println(this.getName() + ": "  + i);
    }        
  }
}                                                                 