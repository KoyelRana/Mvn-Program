

class Multit implements Runnable
{
    public void run()
    {
        System.out.println("runnable interface");
    }
     public static void main(String[] args) {
    Multit t=new Multit();
    //Thread t1=new Thread(t);
t.start();
    }
} 