class MultiThread extends Thread
{
    public void run()
    {
        System.out.println("my first thread");
    }
      public static void main(String[] args) {
    MultiThread ob=new MultiThread();
    ob.start();    
    }
}