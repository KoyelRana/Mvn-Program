package com.kgfsl.log4jtest;
import java.io.IOException;
import com.opencsv.CSVReader;
import java.io.FileReader;
import java.util.*;
import com.opencsv.bean.HeaderColumnNameMappingStrategy;
import com.opencsv.bean.CsvToBean;
import java.util.Random;
import java.util.Scanner;

class OpenCSVParse2BeanHeaderColumn {
public static void main(String[] args) throws IOException {
CSVReader reader = new CSVReader(new FileReader("C://koyelrana//java//log4jtest//empp   .csv"), ',');
    
    HeaderColumnNameMappingStrategy<Employee> beanStrategy = new HeaderColumnNameMappingStrategy<Employee>();
    beanStrategy.setType(Employee.class);
    
    CsvToBean<Employee> csvToBean = new CsvToBean<Employee>();
    List<Employee> emps = csvToBean.parse(beanStrategy, reader);
    
    System.out.println(emps);
    reader.close();
    
    //return emps;

}
}