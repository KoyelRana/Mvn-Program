package com.kgfsl.log4jtest;
import java.io.IOException;
//mport java.io.ArrayIndexOutOfBoundsException;
import com.opencsv.CSVReader;
import java.io.FileReader;
import java.util.Random;
import java.util.*;
import java.util.Scanner;

class OpenCSVLineReader2POJO {
public static void main(String[] args) throws IOException,ArrayIndexOutOfBoundsException {
CSVReader reader = new CSVReader(new FileReader("C://koyelrana//java//log4jtest//emps.csv"), ',');
List<Employee> emps = new ArrayList<Employee>();

String[] row = null;
// Looping reader
while ((row = reader.readNext()) != null) {
Employee emp = new Employee();

// New Employee Construct
emp.setId(row[0]);
emp.setName(row[1]);
emp.setAge(row[2]);
emp.setCountry(row[3]);

emps.add(emp); // ArrayList add

}
System.out.println(emps);

}
}