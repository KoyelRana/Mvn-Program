package com.kgfsl.log4jtest;
import java.io.IOException;
import com.opencsv.CSVReader;
import java.io.FileReader;
import java.util.Random;
import java.util.*;

public class OpenCSVLineReader {
public static void main(String[] args) throws IOException {
CSVReader reader = new CSVReader(new FileReader("C://koyelrana//java//log4jtest//empp.csv"), ',');

String[] row = null;
// Looping reader
while ((row = reader.readNext()) != null) {
System.out.println(row[0] + " # " + row[1] + " # " + row[2]+ " # " + row[3]);
}
}

}