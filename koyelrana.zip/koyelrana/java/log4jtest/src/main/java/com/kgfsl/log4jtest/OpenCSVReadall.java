package com.kgfsl.log4jtest;
import java.io.IOException;
import com.opencsv.CSVReader;
import java.io.FileReader;
import java.util.*;
import java.util.Random;
//import java.util.Scanner;

class OpenCSVReadall{
public static void main(String[] args) throws IOException {
CSVReader reader = new CSVReader(new FileReader("C://koyelrana//java//log4jtest//empp.csv"), ',');
List<String[]> records = reader.readAll();
//records.forEach(System.out:rintln);

for (String[] strings : records) {
System.out.println(Arrays.toString(strings));
}

}
}