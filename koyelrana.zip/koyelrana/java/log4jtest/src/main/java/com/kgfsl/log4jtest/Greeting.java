package com.kgfsl.log4jtest;
public interface Greeting {
	public void say();
}
