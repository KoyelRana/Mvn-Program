package com.kgfsl.log4jtest;
public class HelloGreeting implements Greeting{

	public void say() {
		System.out.println("Hello World");
		
	}

}
