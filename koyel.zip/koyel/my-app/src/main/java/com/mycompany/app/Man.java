package com.mycompany.app;

class Man {
    public int multiplication(int a, int b) {

        return a * b;
    }
}