
class Example
{
int a=30;
int b=35;
public void msg()
{
System.out.println(""+b);
}
class Inner{
public void dip()
{

System.out.println(" "+a);
Example.this.msg();
}

}
public static void main(String arg[])
{
Example ob=new Example();
Example.Inner i=ob.new Inner();

i.dip();


}

}