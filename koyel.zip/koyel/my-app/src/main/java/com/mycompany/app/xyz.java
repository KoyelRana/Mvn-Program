package com.mycompany.app;
public class xyz {

	public static void main(String[] args) {
		
		Book p = new BookBuilder().setid(1).setName("c").setAuthor("koyel").setPubliser("parul").setQuantity(5).getbook();
		Book p1 = new BookBuilder().setid(2).getbook();
		System.out.println(p);
		System.out.println(p1);
	}

}
