package com.mycompany.app;
import java.util.*;
public   class BookBuilder
{
    private  int id;
    private String name;
    private String author;
private String publiser;
private int quantity;

public BookBuilder setid(int id)
{
    this.id=id;
    return this;
}
public BookBuilder setName(String name)
{
    this.name=name;
    return this;
}
public BookBuilder setAuthor(String author)
{
    this.author=author;
    return this;
}
public BookBuilder setPubliser(String publiser)
{
    this.publiser=publiser;
    return this;
}
public BookBuilder setQuantity(int quantity)
{
    this.quantity=quantity;
    return  this;
}
public Book getbook() {
		return new Book(id, name, author, publiser, quantity);
	}
    }
