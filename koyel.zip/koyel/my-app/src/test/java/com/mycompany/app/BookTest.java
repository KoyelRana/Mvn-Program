package com.mycompany.app;

import org.junit.Test;


public class BookTest{
    Book b=new Book();

@Test
public void createBooks(){
   Book p1 = new BookBuilder().setid(1).setAuthor("Author"). setPubliser("Publiser").setQuantity(1).setName("C#").getbook();
		System.out.println(p1);
 
}
@Test
public void testmethod()
{
    b.create();
    System.out.println("jjfj");
}
{

}
}