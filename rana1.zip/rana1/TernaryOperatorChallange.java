
class TernaryOperatorChallange
{
    public static void main(String args[])
    {
    Integer i=42;
    String s= (i<40) ? "best project" : (i>50) ? "powerfull code" : "nobugs";
    s +=(i<42) ? "best programming" : (i<30) ? (i>41) : "no stress";
    System.out.println(s);   
    }
}